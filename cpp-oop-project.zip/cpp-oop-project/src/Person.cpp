#include "Person.h"
#include <iostream>

Person::Person() : name("Unknown"), age(0) {}

Person::Person(const std::string& name, int age) : name(name), age(0) {
    setAge(age);
}

std::string Person::getName() const { return name; }
int Person::getAge() const { return age; }

void Person::setName(const std::string& newName) {
    if (!newName.empty()) name = newName;
}

void Person::setAge(int newAge) {
    if (newAge >= 0 && newAge <= 120) age = newAge;
    else std::cout << "Invalid age ignored: " << newAge << "\n";
}

void Person::display() const {
    std::cout << "Name: " << name << ", Age: " << age << "\n";
}
