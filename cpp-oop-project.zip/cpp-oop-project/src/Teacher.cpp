#include "Teacher.h"
#include <iostream>

Teacher::Teacher() : Person(), subject("N/A"), experienceYears(0) {}

Teacher::Teacher(const std::string& name, int age,
                 const std::string& subject, int experienceYears)
    : Person(name, age), subject(subject), experienceYears(experienceYears) {}

std::string Teacher::getSubject() const { return subject; }
int Teacher::getExperienceYears() const { return experienceYears; }

void Teacher::display() const {
    std::cout << "[Teacher] ";
    Person::display();
    std::cout << "          Subject: " << subject
              << ", Experience: " << experienceYears << " years\n";
}
