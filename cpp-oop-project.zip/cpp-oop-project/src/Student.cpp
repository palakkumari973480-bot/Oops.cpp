#include "Student.h"
#include <iostream>

Student::Student() : Person(), rollNo(0), course("N/A"), cgpa(0.0) {}

Student::Student(const std::string& name, int age, int rollNo,
                 const std::string& course, double cgpa)
    : Person(name, age), rollNo(rollNo), course(course), cgpa(0.0) {
    setCgpa(cgpa);
}

int Student::getRollNo() const { return rollNo; }
double Student::getCgpa() const { return cgpa; }

void Student::setCgpa(double newCgpa) {
    if (newCgpa >= 0.0 && newCgpa <= 10.0) cgpa = newCgpa;
    else std::cout << "Invalid CGPA ignored: " << newCgpa << "\n";
}

void Student::display() const {
    std::cout << "[Student] ";
    Person::display();
    std::cout << "          Roll No: " << rollNo << ", Course: " << course
              << ", CGPA: " << cgpa << "\n";
}
